#include "util.h"
#include "salon.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

const char* NOMBRE_FILE_ORIGIN = "salon_original.sal";
const char* NOMBRE_FILE_DESTINO = "salon_modificado.sal";



void dar_bienvenida(){

    printf("\n\n\t\tBienvenidos al salón de la fama pokemon!\n");
    
}



void mostrar_victoriosos(entrenador_t** entrenadores){

    size_t cant_entrenadores = vtrlen(entrenadores);

    for(size_t i = 0; i < cant_entrenadores; i++){

        salon_mostrar_entrenador(entrenadores[i]);

    }

}



/**
 * Muestra el proceso que se encuentra realizando el operador_salon en un momento determinado de ejecución.
 */
void mostrar_estado_actual(int* operacion_actual){

    if((*operacion_actual) == 1){
        printf("\n    A continuación puede observar a los entrenadores con 3 o más ligas victoriosas:\n");
    }
    else if((*operacion_actual) == 2){
        printf("\n    Inscribiendo a los entrenadores recién llegados al salón...\n    Agregando entrenadores nuevos a la base de datos...\n");
    }
    else if((*operacion_actual) == 3){
        printf("\n      Salón actualizado con éxito!\n");
        printf("\n    A continuación puede observar a los entrenadores con 5 o más ligas victoriosas:\n");
    }
    else if((*operacion_actual) == 4){
        printf("\n\n    Guardando y archivando el salón actualizado...\n");
    }
    else if((*operacion_actual) == 5){
        printf("\n      Guardado salón actualizado exitosamente!\n\n");
    }

    (*operacion_actual)++;

}



/**
 * Reserva en memoria un entranador recibido por parámetro con cierta cantidad de victorias (tambien especificada por parámetro).
 * Devuelve dicho entrenador o NULL en caso de fallo.
 * Debe liberarse el entrenador alojado en memoria.
 * (Notar que solo se inicializa el campo victorias del mismo y se le da un nombre genérico, el equipo 
 * del entrenador no se reserva en memoria).
 */
entrenador_t* inicializacion_entrenador(entrenador_t* entrenador, int cantidad_victorias){

    entrenador = malloc(1*sizeof(entrenador_t));
    if(!entrenador){
        return NULL;
    }

    strcpy(entrenador->nombre, "Trainer");
    entrenador->victorias = cantidad_victorias;
    entrenador->equipo = NULL;

    return entrenador;

}


/**
 * Recibe un salón previamente reservado en memoria y cargado con información de un archivo.
 * Realiza revisiones y actualizaciones al salón.
 * Devuelve 0 si todas las operaciones se llevaron a cabo sin problemas o -1 en caso contrario.
 */
int operador_salon(salon_t* salon){

    int operacion_actual = 1;

    mostrar_estado_actual(&operacion_actual);

    int cant_min_victorias = 3;

    entrenador_t** entrenadores_ganadores = salon_obtener_entrenadores_mas_ganadores(salon, cant_min_victorias);
    if(entrenadores_ganadores == NULL){
        return -1;
    }

    mostrar_victoriosos(entrenadores_ganadores);
    free(entrenadores_ganadores);

    mostrar_estado_actual(&operacion_actual);

    salon_t* aux_salon = salon;

    int victorias_iniciales = 5;

    entrenador_t* entrenador_aux = NULL;

    entrenador_aux = inicializacion_entrenador(entrenador_aux, victorias_iniciales);
    if(entrenador_aux == NULL){
        return -1;
    }

    aux_salon = salon_agregar_entrenador(salon, entrenador_aux);
    if(!aux_salon){
        return -1;
    }

    victorias_iniciales = 7;

    entrenador_aux = inicializacion_entrenador(entrenador_aux, victorias_iniciales);
    if(entrenador_aux == NULL){
        return -1;
    }

    aux_salon = salon_agregar_entrenador(salon, entrenador_aux);
    if(!aux_salon){
        return -1;
    }

    mostrar_estado_actual(&operacion_actual);

    cant_min_victorias = 5;

    entrenadores_ganadores = salon_obtener_entrenadores_mas_ganadores(salon, cant_min_victorias);
    if(entrenadores_ganadores == NULL){
        return -1;
    }

    mostrar_victoriosos(entrenadores_ganadores);
    free(entrenadores_ganadores);

    mostrar_estado_actual(&operacion_actual);

    int resultado_guardado = salon_guardar_archivo(salon, NOMBRE_FILE_DESTINO);

    if(resultado_guardado == -1){
        return -1;
    }

    mostrar_estado_actual(&operacion_actual);
    
    return 0;

}



/*===================================================================== / / =====================================================================*/



int main(){

    dar_bienvenida();

    salon_t* salon = salon_leer_archivo(NOMBRE_FILE_ORIGIN);
    if(salon == NULL){
        return -1;
    }

    int result = operador_salon(salon);
    
    salon_destruir(salon);
    
    return result;

}
