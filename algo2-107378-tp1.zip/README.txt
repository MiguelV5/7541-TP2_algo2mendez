▒▒▒▒▒▒▒▒▒▒▒▒  STACK Y HEAP  ▒▒▒▒▒▒▒▒▒▒▒▒ 

    Stack:
        Se utiliza cuando no se necesíta que la memoria usada sea flexible a cambios
        durante la ejecución del programa, todo lo que aca se aloja es de caracter
        estático.
        La facilidad/obstáculo (dependiendo de lo que se quiera hacer) que presenta es que
        el mismo sistema operativo gestiona su manejo de memoria, lo cual excenta al
        programador de la liberación de la misma, pero impide modificaciones de tamaño de
        reserva.

    Heap:
        A cambio de tener que responsabilizarse del tamaño de alojamiento y liberación
        de memoria, permite hacer uso de la flexibilidad dinámica que no presenta el 
        Stack.
        Todo lo relacionado a su utilización está envuelto en las siguentes funciones.

    Malloc/Realloc/Free
        Son las funciones que posibilitan el uso de memoria dinámica, su reserva por parte
        de malloc, calloc y realloc; y su liberación por parte de free.

        Las funciones malloc y calloc se usan exclusivamente para reservar una porción 
        única en el Heap, y si se quieren usar nuevamente sobre la misma variable 
        primero debe liberarse la memoria que se reservó antes.

        Realloc permite, para una misma variable, hacer modificaciones sobre una reserva
        previa y ampliarla según necesidad. Si no puede ampliar más en cierta región de
        memoria, buscará otra que disponga lo necesario y liberará la memoria anterior.

        Free se usa para liberar toda memoria reservada por el usuario anteriormente.
        Solo se debe liberar memoria reservada.



▒▒▒▒▒▒▒▒▒▒▒▒  Breve explicación de cada función:  ▒▒▒▒▒▒▒▒▒▒▒▒ 

    ▒▒▒▒  ulil.c:  ▒▒▒▒

        --- vtrlen: ---
            Dado que el puntero que recibe es un vector, y se espera que como posicion
            final tenga un puntero NULL, entonces se itera sobre tal vector hasta 
            llegar a tal final, contando cada posicion anterior. Ese contador es la longitud 
            del vector. Precisamente si el puntero recibido era null, ese vector
            es de longitud nula.

        --- vtradd ---
            Se usa el tamaño actual del vector que llega para pedirle a realloc reservar
            un vector de ese tamaño + 2. Un "espacio" para el item nuevo que se añade, y
            otro para recolocar el NULL al final del vector.

        --- vtrfree ---
            Si se libera el puntero al vector, se deja sin liberar cada puntero del
            mismo, por ende se itera en todo el vector y se va liberando cada posición.
            Recién luego de eso se libera el puntero. (Claramente si el puntero que
            llega era NULL, no hay nada por liberar).

        --- split ---
            (Denoto sub-string a cada string pequeño a separar).
            En principio, voy recorriendo el string original hasta toparse con separadores.
            Hago uso entonces de inervalos en el str original, que están determinados por
            las posiciones iniciales y finales de cada sub-string. Dichas posiciones son:

            - En el caso del 1er sub-string: El inicio es el mismo para el string 
            original. Su posición final será previa al primer separador.

            - Para el resto de sub-strings: Su posición inicial en el str original será 
            la del último separador encontrado + 1. 
            Su posicion final será previa al siguiente separador o al fin del str original.

            Dicho intervalo va a ser entonces de tamaño:

            pos_ult_separador - pos_ult_inicial + 1   ---> (El +1 para que se tenga espacio
            para el \0)

            Una vez determinado el intervalo a separar (y habiendo reservado memoria para un 
            string auxiliar "nuevo_sub_str" pequeño del tamaño del intervalo), 
            se transcribe esa porción del str original al nuevo_sub_str.
            Tras transcribir, se añade tal sub-string a un vector de punteros (a strings)
            con vtradd. 

            Se repite la operación hasta llegar al final del str original, y se libera el 
            str auxiliar usado.

        --- fgets_alloc ---
            Hago uso de dos strings reservados. 
            Uno, 'str', que va a ser el que devuelvo y el que va a variar su tamaño
            (en caso de necesitar más espacio para la linea leida), y otro 'str_aux' que se 
            reserva solo una vez, porque se quiere de tamaño fijo (512 bytes).

            Se lee entonces la primera linea con fgets, y si la misma requiere más espacio,
            se inicia una iteración que aumente el tamaño del str las 'n' veces que haga falta 
            para obtener la linea completa. (Cada vez que se aumenta el tamaño, se usa el 
            auxiliar para leer los siguientes 512 bytes e ir concatenandolo al str aumentado).
            
            [PARA VER EXPLICACIÓN SOBRE LA CONDICIÓN DEL ITERADOR, IR A ACLARACIÓN ABAJO DE
            ESTE .txt]

            La variable lector_verif se usa como flag para ver si finaliza el archivo en el
            que se lee.


    ▒▒▒▒  salon.c:  ▒▒▒▒

        --- salon_leer_archivo ---
            Se usa la función 'almacenador_salon', que itera según las lecturas del archivo 
            hasta que el mismo finalice.
            En la iteración, tras haber leido una linea, se usa split para almacenar el 
            contenido individual de cada campo. A su vez, con la cantidad de campos que se
            separen se puede saber si es un pokemon o un entrenador.
            Con los campos separados, ya se puede liberar la linea leida.
            Se va creando un vector de punteros a pokemon con vtradd, y esta misma función
            se utiliza para ir añadiendo cada entrenador al salón una vez que ya tiene todo su 
            equipo pokemon armado. (Recíen después de tenerlo armado, se cambia de
            entrenador y se añade el entrenador previo al salón).
            [PEQUEÑA ACLARACIÓN ABAJO DEL .txt]

        --- salon_guardar_archivo ---
            Se usa un corte de control para escribir en el archivo cada entrenador y los
            pokemon que le corresponden al mismo. Los punteros (entrenador_aux y pokemon_aux)
            auxiliares usados en la función salon_a_texto son para facilitar en gran medida la lectura
            y seguimiento del código.

        --- salon_agregar_entrenador ---
            Agrego al entrenador requerido con vtradd y luego ordeno por burbujeo a los
            entrenadores por orden ascendente de victorias.


        --- salon_obtener_entrenadores_mas_ganadores ---
            Realizo una busqueda lineal de los entrenadores que tengan iguales o más 
            victorias que las indicadas. Los que cumplen la condición son guardados en un 
            vector de punteros a entrenadores 'entrenadores_pedidos', por medio de vtradd.

        --- salon_destruir ---
            Se debe liberar el salón "de dentro hacia afuera" de la estructura para que no
            quede memoria sin liberar.
            Por ende se itera entre los entrenadores para liberar el equipo de cada uno con
            vtrfree (ya que cada equipo es un puntero a punteros a pokemon).
            Tras liberar todos los equipos, se libera el vector de entrenadores, y por 
            último el salón individualmente.




▒▒▒▒▒▒▒▒▒▒▒▒  Aclaraciones:  ▒▒▒▒▒▒▒▒▒▒▒▒ 

    ▒▒▒▒  ulil.c, fgets_alloc, linea 228:  ▒▒▒▒

        El factor 'n' se usa como factor y como sustraendo ya que:
        
        -Cada vez que se  llama a fgets, se obtiene un string de LONGITUD: (TAMANIO_POR_DEFECTO - 1). 
        Esto debido a que SIEMPRE que fgets llega al límite de buffer dado, lo asignado 
        en string[TAMANIO_POR_DEFECTO] es el caracter nulo '\0'.

        -Al llamar multiples veces a fgets, este inicia la lectura de texto DESDE DONDE DEJÓ LA ANTERIOR.

        -Debido a lo anterior, se usa el 'str_aux' de tamaño FIJO (TAMANIO_POR_DEFECTO), tal que al 
        usar fgets, siempre va a tener longitud (TAMANIO_POR_DEFECTO - 1). Se usa para llamar repetidas 
        veces a strcat e ir concatenando el auxiliar en el string al que se le va aumentando el tamaño. 

        -Dicho todo lo anterior, es visible entonces que cada vez que se aumente en uno el valor de 'n', 
        justo se corresponde a lo que decrece 'longitud' del string que se va aumentando con cada realloc. 
        Por ende la comparación en la condición del while es:
        longitud == (n*TAMANIO_POR_DEFECTO) - n ; 'n' veces 512 bytes menos la reducción por
        cada iteración.

        (Seguimiento de lo anterior se puede corroborar en gdb).


    ▒▒▒▒  salon.c, salon_leer_archivo, linea 141:  ▒▒▒▒

        Se controla que se añada el último entrenador cuando el archivo finaliza.


    ▒▒▒▒  main.c:  ▒▒▒▒

        Se incluyen salon.h y util.h para realizar todas las operaciones pedidas.
        Por cada operación se usa el procedimiento 'mostrar_estado_actual' para dar
        cuenta de la operación que se encuentra realizando al ejecutarse.

        _______________________________________________________________________________