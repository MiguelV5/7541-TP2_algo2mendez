#include "salon.h"
#include "util.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

const char SEPARADOR = ';';
#define CANT_CAMPOS_ENTRENADOR 2
#define CANT_CAMPOS_POKEMON 6
#define FORMATO_W_ENTRENADOR "%s;%i\n" // FORMATO_W_(...) == FORMATO ESCRITURA (...)
#define FORMATO_W_POKEMON "%s;%i;%i;%i;%i;%i\n"



/**
 * Le asigna valores leidos de un archivo a los campos de un entrenador (EXCEPTO el equipo) previamente reservado en memoria
*/
void asignar_entrenador(entrenador_t* entrenador, char** valores_leidos){
    
    strcpy(entrenador->nombre, valores_leidos[0]);
    entrenador->victorias = atoi(valores_leidos[1]);
    entrenador->equipo = NULL;

}

/**
 * Le asigna valores leidos de un archivo a los campos de un pokemon previamente reservado en memoria
*/
void asignar_pokemon(pokemon_t* pokemon, char** valores_leidos){
    
    strcpy(pokemon->nombre, valores_leidos[0]);
    pokemon->nivel = atoi(valores_leidos[1]);
    pokemon->defensa = atoi(valores_leidos[2]);
    pokemon->fuerza = atoi(valores_leidos[3]);
    pokemon->inteligencia = atoi(valores_leidos[4]);
    pokemon->velocidad = atoi(valores_leidos[5]);

}

/**
 * Actualiza un entrenador y guarda el entrenador previo al salón
 * Devuelve la dirección al entrenador actualizado si pudo realizarlo o NULL en caso contrario.
 * -El salón debe llegar previamente reservado en memoria.
 * -valores_a_asignar debe llegar con valores previamente leidos.
*/
entrenador_t* almacenador_entrenadores(entrenador_t* entrenador_act, entrenador_t* entrenador_prev, bool* es_primer_entrenador, char** valores_a_asignar, salon_t* salon){
    
    entrenador_prev = entrenador_act;

    entrenador_act = malloc(1*sizeof(entrenador_t));
    if(entrenador_act == NULL){
        return false;
    }

    if((*es_primer_entrenador) == false){
        salon->entrenadores = vtradd(salon->entrenadores, entrenador_prev);  
    }
    else if((*es_primer_entrenador) == true){
        (*es_primer_entrenador) = false;
    }

    asignar_entrenador(entrenador_act, valores_a_asignar);

    return entrenador_act;

}


/**
 * Actualiza un pokemon con valores_a_asignar y añade dicho pokemon al equipo de un entrenador.
 * Devuelve la dirección al pokemon añadido si pudo hacerse o NULL en caso contrario.
 * -El entrenador debe llegar previamente reservado en memoria.
 * -valores_a_asignar debe llegar con valores previamente leidos.
*/
pokemon_t* almacenador_pokemon(pokemon_t* pokemon, char** valores_a_asignar, entrenador_t* entrenador){
    
    pokemon = malloc(1*sizeof(pokemon_t));
    if(pokemon == NULL){
        return NULL;
    }

    asignar_pokemon(pokemon, valores_a_asignar);

    entrenador->equipo = vtradd(entrenador->equipo, pokemon);

    return pokemon;

}


/**
 * Carga en memoria un archivo de salón (ya abierto).
 * Devuelve el salón cargado.
 * -Si no puede leer el archivo o hay un error, devuelve NULL.
 * -El cierre del archivo queda en disposicion de la función de donde se le llama.
 */
salon_t* almacenador_salon(char* linea_leida, FILE* archivo_sal, salon_t* salon){

    salon->entrenadores = NULL;

    entrenador_t* entrenador_aux = NULL;
    entrenador_t* entrenador_prev = NULL; //Cuando se cambie a un entrenador nuevo, con este se guardará el anterior al salón.
    pokemon_t* pokemon_aux = NULL;

    bool es_primer_entrenador = true;

    char** campos_leidos = NULL;
    size_t cantidad_campos = 0;

    while(linea_leida != NULL){
    
        campos_leidos = split(linea_leida, SEPARADOR);
        if(campos_leidos == NULL){
            return NULL;
        }

        free(linea_leida);
        
        cantidad_campos = vtrlen(campos_leidos);

        if(cantidad_campos == CANT_CAMPOS_ENTRENADOR){

            entrenador_aux = almacenador_entrenadores(entrenador_aux, entrenador_prev, &es_primer_entrenador, campos_leidos, salon);
            if(entrenador_aux == NULL){
                return NULL;
            }
            
        }
        else if(cantidad_campos == CANT_CAMPOS_POKEMON){

            pokemon_aux = almacenador_pokemon(pokemon_aux, campos_leidos, entrenador_aux);
            if(pokemon_aux == NULL){
                return NULL;
            }

        }

        linea_leida = fgets_alloc(archivo_sal);

        if(linea_leida == NULL){
            salon->entrenadores = vtradd(salon->entrenadores, entrenador_aux);
        }

        vtrfree(campos_leidos);
    
    }

    return salon;

}



/**
 * Escribe un salon en un archivo de texto (previamente abierto).
 * Devuelve la cantidad de entrenadores escritos o -1 en caso de error.
 */
int salon_a_texto(salon_t* salon, FILE* archivo_nuevo){

    entrenador_t* entrenador_aux = NULL;
    pokemon_t* pokemon_aux = NULL;

    size_t largo_entrenadores = vtrlen(salon->entrenadores);
    size_t largo_pokemones = 0;

    int cant_entrenadores = 0;

    int i = 0;
    int j = 0;

    while(i < largo_entrenadores){
        
        entrenador_aux = salon->entrenadores[i];
        fprintf(archivo_nuevo, FORMATO_W_ENTRENADOR, entrenador_aux->nombre, entrenador_aux->victorias);

        largo_pokemones = vtrlen(entrenador_aux->equipo);
        
        while((j < largo_pokemones) && (i < largo_entrenadores)){

            pokemon_aux = entrenador_aux->equipo[j];

            fprintf(archivo_nuevo, FORMATO_W_POKEMON, pokemon_aux->nombre, pokemon_aux->nivel, pokemon_aux->defensa, pokemon_aux->fuerza, pokemon_aux->inteligencia, pokemon_aux->velocidad);

            j++;

        }

        cant_entrenadores++;
        j = 0;
        i++;

    }

    return cant_entrenadores;

}





/**
 * Ordena un vector de entrenadores según victorias de menor a mayor.
 * Devuelve el vector ordenado o NULL en caso de error.
 */
entrenador_t** ordenado_entrenadores(entrenador_t** entrenadores){

    if(!entrenadores){
        printf("\n\t Error: Falla al ordenar los entrenadores por victorias.\n");
        return NULL;
    }
    
    entrenador_t* auxiliar = NULL;
    size_t longitud = vtrlen(entrenadores);

    for(size_t i = 0; i < longitud; i++){

        for(size_t j = 0; j < (longitud - 1 - i); j++){
            
            if( (entrenadores[j]->victorias) > (entrenadores[j+1]->victorias) ){

                auxiliar = entrenadores[j];
                entrenadores[j] = entrenadores[j+1];
                entrenadores[j+1] = auxiliar;

            }

        }

    }

    return entrenadores;

}








/*===================================================================== / / =====================================================================*/





/**
 * Lee archivo y lo carga en memoria.
 *
 * Si no puede leer el archivo o hay un error, devuelve NULL.
 */
salon_t* salon_leer_archivo(const char* nombre_archivo){
    
    FILE* archivo_sal = fopen(nombre_archivo, "r");
    if(archivo_sal == NULL){

        printf("\n\t Error: No se pudo abrir el archivo.\n");
        return NULL;

    }
    
    salon_t* salon = NULL;
    salon = realloc(salon, 1*sizeof(salon_t));
    if(!salon){

        printf("\n\t Error: Fallo al reservar memoria para el salón.\n");
        fclosen(archivo_sal);
        return NULL;

    }

    char* linea_leida = fgets_alloc(archivo_sal);
    if(linea_leida == NULL){

        printf("\n\t Error: Fallo al leer una linea del archivo.\n");
        free(salon);
        fclosen(archivo_sal);
        return NULL;

    }
   

    salon = almacenador_salon(linea_leida, archivo_sal, salon);
    if(!salon){

        printf("\n\t Error: No se pudo cargar la lectura del archivo a un salón.\n");
        free(linea_leida);
        fclosen(archivo_sal);
        return NULL;

    }

    fclosen(archivo_sal);

    return salon; 

}



/**
 * Guarda el salon a un archivo.
 *
 * Devuelve la cantidad de entrenadores guardados o -1 en caso de error.
 */
int salon_guardar_archivo(salon_t* salon, const char* nombre_archivo){
    
    if(!salon){

        printf("\n\t Error: No se pudo guardar el salon a un archivo.\n");
        return -1;

    }

    FILE* archivo_nuevo = fopen(nombre_archivo, "w");
    if(archivo_nuevo == NULL){

        printf("\n\t Error: No se pudo guardar el salon a un archivo.\n");
        return -1;

    }

    int cant_entrenadores = 0;

    cant_entrenadores = salon_a_texto(salon, archivo_nuevo);

    fclosen(archivo_nuevo);

    return cant_entrenadores;

}



/**
 * Agrega un entrenador al salon.
 *
 * El entrenador, como todos los pokemon del mismo, deben residir en memoria
 * dinámica y debe ser posible de liberar todo usando free. Una vez agregado al
 * salon, el salon toma posesión de dicha memoria y pasa a ser su
 * responsabilidad liberarla.
 *
 * Devuelve el salon o NULL en caso de error.
 */
salon_t* salon_agregar_entrenador(salon_t* salon, entrenador_t* entrenador){

    if((!salon) || (!entrenador)){

        printf("\n\t Error: No se pudo agregar el entrenador al salon.\n");
        return NULL;

    }

    salon->entrenadores = vtradd(salon->entrenadores, entrenador);
    if(salon->entrenadores == NULL){

        printf("\n\t Error: No se pudo agregar el entrenador al salon.\n");
        return NULL;

    }

    salon->entrenadores = ordenado_entrenadores(salon->entrenadores);
    
    return salon;
}



/**
 * Busca en el salon entrenadores que hayan ganado por lo menos cantidad_minima_victorias batallas.
 *
 * Devuelve un vector de entrenadores a liberar por el usuario usando free o NULL en caso de error.
 */
entrenador_t** salon_obtener_entrenadores_mas_ganadores(salon_t* salon, int cantidad_minima_victorias){
    
    if(!salon){

        printf("\n\t Error: Se intentó obtener entrenadores de un salón inexistente.\n");
        return NULL;

    }

    entrenador_t** entrenadores_pedidos = NULL;
    size_t longitud_origin = vtrlen(salon->entrenadores);

    for(size_t i = 0; i < longitud_origin; i++){

        if(salon->entrenadores[i]->victorias >= cantidad_minima_victorias){

            entrenadores_pedidos = vtradd(entrenadores_pedidos, salon->entrenadores[i]);

        }

    }

    return entrenadores_pedidos;

}



/**
 * Muestra por pantalla los datos de un entrenador y sus pokemon.
 */
void salon_mostrar_entrenador(entrenador_t* entrenador){
    
    if(!entrenador){

        printf("\n\t Error: No se pudo mostrar el entrenador.\n");
        return;

    }

    size_t i = 0;
    size_t cant_pokemones = vtrlen(entrenador->equipo);

    printf("\n\n\tENTRENADOR: %s.\n\tLIGAS VICTORIOSAS: %i.\n\tEQUIPO POKEMON:", entrenador->nombre, entrenador->victorias);
    
    while(i < cant_pokemones){

        printf("\n\t    Nombre: %s.", entrenador->equipo[i]->nombre);
        printf("\n\t\tNivel: %i.", entrenador->equipo[i]->nivel);
        printf("\n\t\tDefensa: %i.", entrenador->equipo[i]->defensa);
        printf("\n\t\tFuerza: %i.", entrenador->equipo[i]->fuerza);
        printf("\n\t\tInteligencia: %i.", entrenador->equipo[i]->inteligencia);
        printf("\n\t\tVelocidad: %i.\n", entrenador->equipo[i]->velocidad);
        
        i++;

    }

}



/**
 * Libera toda la memoria utilizada por el salon, los entrenadores y todos los pokemon.
 */
void salon_destruir(salon_t* salon){

    if(!salon){
        return;
    }

    size_t i = 0;

    size_t cant_entrenadores = vtrlen(salon->entrenadores);

    while(i < cant_entrenadores){

        vtrfree(salon->entrenadores[i]->equipo);
        i++;

    }

    vtrfree(salon->entrenadores);
    free(salon);

}
